Online Music Player — Salaar Ceasefire BGM

Languages and Technologies Used:
1. HTML: Structure of the webpage.
2. CSS: Styling and responsive layout.
3. JavaScript: Dynamic functionality (play tracks, update album cover and title).
4. YouTube Embed: For playing music.
5. Figma Embed: Display UI design mockup.
6. Adobe XD Embed: Display UI design mockup.

Short Description:
This project is an Online Music Player that allows users to play background music tracks directly from YouTube. 
It dynamically updates the album cover, track title, and embedded YouTube video when a user clicks a button. 
It also includes embedded UI designs from Figma and Adobe XD to showcase the planned interface and user experience. 
The player is fully responsive for desktop, tablet, and mobile devices.